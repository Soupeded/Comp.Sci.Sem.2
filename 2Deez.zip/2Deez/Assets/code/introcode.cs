﻿using UnityEngine;
using System.Collections;

public class introcode : MonoBehaviour
{
    public int counter;
    public int x;
    void start() {
        counter = 0;
	x = 0;
	print("The value of counter is: " + counter);

    }
    void Update() {
        x = x + 1;
        counter = x;
	print("The counter variable can also be changed here: " + counter);
    }
}