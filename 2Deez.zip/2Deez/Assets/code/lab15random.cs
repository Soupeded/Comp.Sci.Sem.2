﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class lab15random : MonoBehaviour {

	public Vector3 hellokitty;
	public float x;
	public float y;

	// Use this for initialization
	void Start () {
		hellokitty = new Vector3(x, y, 0.0f);
		transform.position = hellokitty;
	}
	
	// Update is called once per frame
	void Update () {
		x = Random.Range(-11,11);
		y = Random.Range(-3,3);
		hellokitty = new Vector3(x, y, 0.0f);
		transform.position = hellokitty;
	}
}
