﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class morecode : MonoBehaviour {
	public int x;
	// Use this for initialization
	void Start () {
		print("I love cupcakes!");
		x = 0;
	}
	
	// Update is called once per frame
	void Update () {
		print(x);
		
	}
}
