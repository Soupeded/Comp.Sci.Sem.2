﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class recyclexercise: MonoBehaviour
{

    public Vector3 superman;
    public float x;
    public float move;

    // Use this for initialization
    void Start()
    {
        x = -11.0f;
        move = 0.1f;
        superman = new Vector3(x, 0f, 0.0f);
        transform.position = superman;
        print("x=" + transform.position.x);
        print("y=" + transform.position.y);
    }

    // Update is called once per frame
    void Update()
    {
        x = x + move;
        superman = new Vector3(x, 0f, -1.0f);
        transform.position = superman;
        if (x > 16)
        {
            x = -16;
        }
        if (x < -16)
        {
            x = 16;
        }
        if (Input.GetKey("1"))
        {
            move = 1;
        }
        if (Input.GetKey("2"))
        {
            move = -1;
        }
        if (Input.GetKey("3"))
        {
            move = 0.1f;
        }
        
    }
    public void increaseSpeed()
        {
            move = 3;
        }
    public void decreaseSpeed()
        {
        move = -3;
        }
}