﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class recycle : MonoBehaviour {

	public Vector3 llama;
	public float x;

	// Use this for initialization
	void Start () {
		x = -11.0f;
		llama = new Vector3(x, -1.0f, 0.0f);
		transform.position = llama;
		print("x="+transform.position.x);
		print("y="+transform.position.y);
	}
	
	// Update is called once per frame
	void Update () {
		x = x + 0.1f;
		llama = new Vector3(x, -1.0f, 0.0f);
		transform.position = llama;
		if(x>17){
			x = -17;
		}
	}
}
