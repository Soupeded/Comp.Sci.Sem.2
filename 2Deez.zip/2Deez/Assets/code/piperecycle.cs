﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class piperecycle : MonoBehaviour {
    float count;
    float r;
	// Use this for initialization
	void Start () {
        count = transform.position.x;
        r = Random.Range(-2, 4);
	}
	
	// Update is called once per frame
	void Update () {
		if (count <= -15f)
        {
            count = 15f;
            r = Random.Range(-4, 4);
        }
        transform.position = new Vector3(count, r, -1);
        count = count - 0.1f;
	}
}
