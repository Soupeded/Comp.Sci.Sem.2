﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class driving : MonoBehaviour {
	public Vector3 joe;
	public float moveSpeed;
	public float rotateSpeed;
	// Use this for initialization
	void Start () {
		moveSpeed = 0.1f;
		rotateSpeed = 50f;
	}
	
	// Update is called once per frame
	void Update () {
		if(Input.GetKey("w")){
			transform.Translate(Vector3.up * moveSpeed);
		}
		if(Input.GetKey("s")){
			transform.Translate(-Vector3.up * moveSpeed);
		}
		if(Input.GetKey("a")){
			transform.Translate(Vector3.left * moveSpeed);
		}
		if(Input.GetKey("d")){
			transform.Translate(Vector3.right * moveSpeed);
		}
		if(Input.GetKey("q")){
			transform.Rotate(Vector3.forward, rotateSpeed);
		}
	}
}