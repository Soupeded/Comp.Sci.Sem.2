﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class ground : MonoBehaviour {

	public Vector3 brick;
	public float x;

	// Use this for initialization
	void Start () {
		x = 35.73f;
		brick = new Vector3(x, -1.0f, 0.0f);
		transform.position = brick;
		print("x="+transform.position.x);
	}
	
	// Update is called once per frame
	void Update () {
		x = x - 0.1f;
		brick = new Vector3(x, -15.55f, 0f);
		transform.position = brick;
		if(x<-40){
			x = 35.73f;
		}
	}
}
