﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class flappymario : MonoBehaviour {
    public GameObject Camera;
	public Vector3 mario;
	public float jumpSpeed;
    public Text obj;
    int counter;
    int flag;
	// Use this for initialization
	void Start () {
		jumpSpeed = 0.25f;
        counter = 5;
        obj.text = counter.ToString();
        flag = 0;
        
	}

    // Update is called once per frame
    void Update() {
        obj.text = counter.ToString();
        if (Input.GetKey("w")) {
            transform.Translate(Vector3.up * jumpSpeed);
        }
    }
    void OnTriggerEnter2D(Collider2D coll)
        {
        if (flag == 0)
        {
            print("COLLISION DETECTED!");
            counter = counter - 1;
            flag = 1;
        }
       
        }

    void OnTriggerExit2D(Collider2D coll)
    {
    if (flag == 1)
        {
            flag = 0;
        }
    if (counter == 0)
        {
            Camera.transform.position = new Vector3(-64.9f, 30.1f, -10f);
            mario = new Vector3(-64.9f, 30.1f, 5f);
            transform.position = mario;
        }
    }

}
