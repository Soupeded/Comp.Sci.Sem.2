﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class random : MonoBehaviour {

	public Vector3 ortkam;
	public float x;
	public float y;

	// Use this for initialization
	void Start () {
		ortkam = new Vector3(x, y, 0.0f);
		transform.position = ortkam;
	}
	
	// Update is called once per frame
	void Update () {
		x = Random.Range(-11,11);
		y = Random.Range(-3,3);
		ortkam = new Vector3(x, y, 0.0f);
		transform.position = ortkam;
	}
}
