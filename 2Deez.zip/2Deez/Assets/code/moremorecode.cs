﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class moremorecode : MonoBehaviour {

	public Vector3 joe;
	public float x;

	// Use this for initialization
	void Start () {
		x = -9.0f;
		joe = new Vector3(x, -1.0f, 0.0f);
		transform.position = joe;
	}
	
	// Update is called once per frame
	void Update () {
		x = x + 0.1f;
		joe = new Vector3(x, -1.0f, 0.0f);
		transform.position = joe;
		
	}
}
